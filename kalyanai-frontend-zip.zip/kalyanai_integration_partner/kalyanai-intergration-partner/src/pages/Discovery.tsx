import { useEffect, useState } from "react";

type Job = {
  id: string;
  filename: string;
  status: "uploaded" | "processing" | "done" | "error";
  createdAt: string;
  resultSummary?: string;
};

// 🔗 Your backend on the VPS
const API_BASE_URL = "http://185.151.29.141:3001";

export default function Discovery() {
  const [status, setStatus] = useState("Idle — waiting for a recording.");
  const [file, setFile] = useState<File | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);

  const fetchJobs = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/jobs`);
      if (!response.ok) {
        return;
      }
      const data: Job[] = await response.json();
      setJobs(data);
    } catch {
      // Ignore errors for now
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const handleRunAnalysis = async () => {
    if (!file) {
      setStatus("Please upload a file first.");
      return;
    }

    setStatus("Uploading...");

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch(`${API_BASE_URL}/process-file`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data: { success?: boolean } = await response.json();

      if (data && data.success) {
        setStatus("File uploaded. Processing started.");
        fetchJobs();
      } else {
        setStatus("Upload failed.");
      }
    } catch (_error) {
      setStatus("Upload failed.");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto max-w-3xl px-4 py-12">
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-extrabold text-[#191970] mb-3">
            Discovery Call Automation
          </h1>
          <p className="text-base md:text-lg text-muted-foreground">
            Upload a call recording and let Kalyan AI analyse it.
          </p>
        </header>

        <section className="rounded-xl border border-border bg-card/60 backdrop-blur-sm p-6 space-y-4 shadow-sm">
          <div>
            <label
              htmlFor="recording"
              className="block text-sm font-medium text-foreground mb-2"
            >
              Upload recording
            </label>
            <input
              id="recording"
              type="file"
              onChange={(event) => {
                const selectedFile = event.target.files?.[0] ?? null;
                setFile(selectedFile);
              }}
              className="block w-full text-sm file:mr-4 file:rounded-md file:border-0 file:bg-[#06B6D4] file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:bg-[#0894ac] cursor-pointer"
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleRunAnalysis}
              className="inline-flex items-center justify-center rounded-md bg-[#06B6D4] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#0894ac] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#06B6D4]"
            >
              Run Analysis
            </button>

            <button
              type="button"
              onClick={fetchJobs}
              className="inline-flex items-center justify-center rounded-md border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-accent"
            >
              Refresh
            </button>
          </div>

          <p
            className="text-sm text-muted-foreground"
            data-testid="discovery-status"
          >
            {status}
          </p>

          <section className="mt-6">
            <h2 className="text-xl font-semibold mb-3">Recent Calls</h2>
            {jobs.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                No recent calls yet.
              </p>
            ) : (
              <ul className="space-y-3">
                {jobs.map((job) => (
                  <li
                    key={job.id}
                    className="rounded-lg border border-border bg-background/50 p-3"
                  >
                    <div className="text-sm font-medium">{job.filename}</div>
                    <div className="text-xs text-muted-foreground">
                      Status: {job.status} •{" "}
                      {new Date(job.createdAt).toLocaleString()}
                    </div>
                    {job.resultSummary && (
                      <p className="mt-1 text-sm text-foreground">
                        {job.resultSummary}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>
        </section>
      </div>
    </div>
  );
}